
// This component has been replaced by RecordRow.tsx for a daily tabular ledger format.
export {};
